package src;
import javax.swing.*;
import java.awt.*;

public class TelaDoacao {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tela de Doação");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLayout(new BorderLayout());

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));

        // Campo nome
        painel.add(new JLabel("Digite seu nome:"));
        JTextField campoNome = new JTextField();
        campoNome.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(campoNome);

        // Campo valor
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Digite o valor da doação (R$):"));
        JTextField campoValor = new JTextField();
        campoValor.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(campoValor);

        // Combo de categoria
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Escolha uma categoria:"));
        JComboBox<String> comboCategoria = Categoria.criarComboBoxCategoria();
        comboCategoria.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(comboCategoria);

        // Combo de pagamento
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Escolha o tipo de pagamento:"));
        JComboBox<String> comboPagamento = Pagamento.criarComboBoxPagamento();
        comboPagamento.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(comboPagamento);

        // Painel dinâmico do tipo de pagamento
        JPanel painelPagamento = Pagamento.criarPainelPagamento(comboPagamento);
        painel.add(Box.createVerticalStrut(10));
        painel.add(painelPagamento);

        painel.add(Box.createVerticalStrut(10));

        // Painel auxiliar botao doar
        JPanel painelBtn = new JPanel();
        painelBtn.setLayout(new FlowLayout(FlowLayout.CENTER)); // centraliza o conteudo 
        JButton btnDoar = new JButton("Doar");
        painelBtn.add(btnDoar);
        painelBtn.setOpaque(false); // deixa o fundo transparente para manter a estética do painel principal
        painel.add(painelBtn);
        
        btnDoar.addActionListener(e -> {
            String nome = campoNome.getText().trim();
            String valor = campoValor.getText().trim();
            String categoriaSelecionada = (String) comboCategoria.getSelectedItem();
            String pagamentoSelecionado = (String) comboPagamento.getSelectedItem();

            if (nome.isEmpty() || valor.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Preencha todos os campos obrigatórios.", "Erro", JOptionPane.WARNING_MESSAGE);
            } else if ("Definir categoria".equals(categoriaSelecionada)) {
                JOptionPane.showMessageDialog(frame, "Escolha uma categoria válida.", "Aviso", JOptionPane.WARNING_MESSAGE);
            } else if ("Definir tipo de pagamento".equals(pagamentoSelecionado)) {
                JOptionPane.showMessageDialog(frame, "Escolha um tipo de pagamento válido.", "Aviso", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame,
                        "Doação realizada com sucesso!\nObrigado, " + nome + "!",
                        "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        frame.add(painel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
