package src;
import javax.swing.*;
import java.awt.*;

public class Pagamento {
    public static JComboBox<String> criarComboBoxPagamento() {
        String[] formasPagamento = {
            "Definir tipo de pagamento",
            "PIX",
            "Cartão de Crédito",
            "Transferência Bancária"
        };
        return new JComboBox<>(formasPagamento);
    }

    public static JPanel criarPainelPagamento(JComboBox<String> comboPagamento) {
        JPanel painelPagamento = new JPanel(new CardLayout());

        // Painel vazio
        JPanel vazio = new JPanel();

        // PIX
        JPanel painelPix = new JPanel(new GridLayout(2, 1));
        painelPix.add(new JLabel("PIX"));
        painelPix.add(new JLabel("Chave PIX: abc123xyz@banco.com"));

        // Cartão de Crédito
        JPanel painelCartao = new JPanel(new GridLayout(10, 2));
        painelCartao.add(new JLabel("Número do Cartão:"));
        painelCartao.add(new JTextField());
        painelCartao.add(new JLabel("Nome impresso no Cartão:"));
        painelCartao.add(new JTextField());
        painelCartao.add(new JLabel("CVC:"));
        painelCartao.add(new JTextField());

        // Transferência
        JPanel painelTransferencia = new JPanel(new GridLayout(2, 1));
        painelTransferencia.add(new JLabel("Transferência Bancária"));
        painelTransferencia.add(new JLabel("Agência: 0001 | Conta: 123456-7"));

        painelPagamento.add(vazio, "Definir tipo de pagamento");
        painelPagamento.add(painelPix, "PIX");
        painelPagamento.add(painelCartao, "Cartão de Crédito");
        painelPagamento.add(painelTransferencia, "Transferência Bancária");

        comboPagamento.addActionListener(e -> {
            CardLayout cl = (CardLayout) (painelPagamento.getLayout());
            String selected = (String) comboPagamento.getSelectedItem();
            cl.show(painelPagamento, selected);
        });

        return painelPagamento;
    }
}
