package src;
import javax.swing.*;

public class Categoria {
    public static JComboBox<String> criarComboBoxCategoria() {
        String[] categorias = {
            "Definir categoria",
            "Saúde",
            "Educação",
            "Meio Ambiente",
            "Animais",
            "Outros"
        };
        return new JComboBox<>(categorias);
    }
}
