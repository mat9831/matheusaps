package libs;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Pagamento {
    private int id;
    private String nomeDoador;
    private BigDecimal valor;
    private String formaPagamento;
    private LocalDate data;
    private Map<String, String> detalhes;

    public Pagamento(int id, String nomeDoador, BigDecimal valor, String formaPagamento, LocalDate data) {
        this.id = id;
        this.nomeDoador = nomeDoador;
        this.valor = valor;
        this.formaPagamento = formaPagamento;
        this.data = data;
        this.detalhes = new HashMap<>();
    }

    public int getId() {
        return id;
    }

    public String getNomeDoador() {
        return nomeDoador;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public LocalDate getData() {
        return data;
    }

    public Map<String, String> getDetalhes() {
        return detalhes;
    }

    public void setDetalhes(Map<String, String> detalhes) {
        this.detalhes = detalhes;
    }
}
