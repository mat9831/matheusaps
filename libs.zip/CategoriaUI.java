package libs;

import javax.swing.*;

public class CategoriaUI {
    public static JComboBox<Categoria> criarComboBoxCategoria() {
        JComboBox<Categoria> combo = new JComboBox<>();
        combo.addItem(new Categoria("Definir categoria"));
        combo.addItem(new Categoria("Educação"));
        combo.addItem(new Categoria("Saúde"));
        combo.addItem(new Categoria("Alimentação"));
        return combo;
    }
}
