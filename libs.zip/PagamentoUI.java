package libs;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.util.Map;

public class PagamentoUI {

    public static JComboBox<String> criarComboBoxFormaPagamento() {
        JComboBox<String> combo = new JComboBox<>();
        combo.addItem("Definir tipo de pagamento");
        combo.addItem("PIX");
        combo.addItem("Transferência Bancária");
        combo.addItem("Cartão de Crédito");
        return combo;
    }

    public static JPanel criarPainelDetalhesPagamento(JComboBox<String> comboPagamento,
                                                    Map<String, JTextField> camposExtras) {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new java.awt.Color(180,180,180)),
                "Detalhes do Pagamento",
                TitledBorder.LEFT, TitledBorder.TOP));
        painel.setAlignmentX(Component.CENTER_ALIGNMENT);

        comboPagamento.addActionListener(e -> {
            painel.removeAll();
            camposExtras.clear();

            String forma = (String) comboPagamento.getSelectedItem();

            if ("PIX".equals(forma)) {
                // linha centralizada com label, campo não-editável e botão copiar
                JPanel linha = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
                linha.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel lbl = new JLabel("Chave PIX:");
                JTextField txt = new JTextField("org.fundacao@gmail.com", 20);
                txt.setEditable(false);
                txt.setMaximumSize(new Dimension(240, 26));

                JButton btnCopiar = new JButton("Copiar");
                btnCopiar.addActionListener(a -> {
                    Toolkit.getDefaultToolkit().getSystemClipboard()
                        .setContents(new StringSelection(txt.getText()), null);
                    JOptionPane.showMessageDialog(painel, "Chave PIX copiada!");
                });

                linha.add(lbl);
                linha.add(txt);
                linha.add(btnCopiar);

                painel.add(Box.createVerticalStrut(6));
                painel.add(linha);
                painel.add(Box.createVerticalStrut(6));

            } else if ("Transferência Bancária".equals(forma)) {
                // três linhas centralizadas com campos não-editáveis
                JPanel l1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
                l1.setAlignmentX(Component.CENTER_ALIGNMENT);
                l1.add(new JLabel("Banco:"));
                JTextField tfBanco = new JTextField("001 - Banco do Brasil", 20);
                tfBanco.setEditable(false);
                tfBanco.setMaximumSize(new Dimension(240, 26));
                l1.add(tfBanco);

                JPanel l2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
                l2.setAlignmentX(Component.CENTER_ALIGNMENT);
                l2.add(new JLabel("Agência:"));
                JTextField tfAg = new JTextField("0001", 10);
                tfAg.setEditable(false);
                l2.add(tfAg);

                JPanel l3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
                l3.setAlignmentX(Component.CENTER_ALIGNMENT);
                l3.add(new JLabel("Conta:"));
                JTextField tfC = new JTextField("67890-1", 12);
                tfC.setEditable(false);
                l3.add(tfC);

                painel.add(Box.createVerticalStrut(6));
                painel.add(l1);
                painel.add(l2);
                painel.add(l3);
                painel.add(Box.createVerticalStrut(6));

            } else if ("Cartão de Crédito".equals(forma)) {
                // campos editáveis (serão capturados pelo map camposExtras)
                JPanel p1 = linhaCampoCentral("Número do Cartão:", "Número do Cartão", camposExtras, 16);
                JPanel p2 = linhaCampoCentral("Nome no Cartão:", "Nome no Cartão", camposExtras, 20);
                JPanel p3 = linhaCampoCentral("Validade (MM/AA):", "Validade", camposExtras, 7);
                JPanel p4 = linhaCampoCentral("CVV:", "CVV", camposExtras, 5);

                painel.add(Box.createVerticalStrut(6));
                painel.add(p1);
                painel.add(p2);
                painel.add(p3);
                painel.add(p4);
                painel.add(Box.createVerticalStrut(6));
            }

            painel.revalidate();
            painel.repaint();
        });

        return painel;
    }

    // Helper: cria uma linha centralizada com label + textfield (adiciona ao mapa)
    private static JPanel linhaCampoCentral(String rotulo, String chave, Map<String, JTextField> camposExtras, int cols) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        p.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel lbl = new JLabel(rotulo);
        JTextField txt = new JTextField(cols);
        txt.setMaximumSize(new Dimension(260, 26));
        camposExtras.put(chave, txt);
        p.add(lbl);
        p.add(txt);
        return p;
    }
}
