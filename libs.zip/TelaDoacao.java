package libs;

import javax.swing.*;
import java.math.RoundingMode;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.time.LocalDate;

public class TelaDoacao {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tela de Doação");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(520, 620);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null); // centraliza

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        // Nome
        painel.add(new JLabel("Digite seu nome:"));
        JTextField campoNome = new JTextField();
        campoNome.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(campoNome);

        // Valor
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Digite o valor da doação (R$):"));
        JTextField campoValor = new JTextField();
        campoValor.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(campoValor);

        // Categoria
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Escolha uma categoria:"));
        JComboBox<Categoria> comboCategoria = CategoriaUI.criarComboBoxCategoria();
        comboCategoria.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(comboCategoria);

        // Forma de Pagamento
        painel.add(Box.createVerticalStrut(10));
        painel.add(new JLabel("Escolha o tipo de pagamento:"));
        JComboBox<String> comboPagamento = PagamentoUI.criarComboBoxFormaPagamento();
        comboPagamento.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        painel.add(comboPagamento);

        // Painel compacto de detalhes (sem TextArea gigante)
        Map<String, JTextField> camposExtras = new HashMap<>();
        JPanel painelDetalhes = PagamentoUI.criarPainelDetalhesPagamento(comboPagamento, camposExtras);
        painelDetalhes.setAlignmentX(JComponent.LEFT_ALIGNMENT);
        painel.add(Box.createVerticalStrut(10));
        painel.add(painelDetalhes);

        // Botões
        painel.add(Box.createVerticalStrut(18));
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btnRegistrar = new JButton("Registrar Doação");
        JButton btnVer = new JButton("Ver Registros");
        botoes.add(btnRegistrar);
        botoes.add(btnVer);
        painel.add(botoes);

        // Registros
        List<Pagamento> pagamentos = new ArrayList<>();
        List<Categoria> categoriasAssociadas = new ArrayList<>();

        // Ação Registrar
        btnRegistrar.addActionListener(e -> {
            String nome = campoNome.getText().trim();
            String valorTxt = campoValor.getText().trim();
            Categoria catSel = (Categoria) comboCategoria.getSelectedItem();
            String forma = (String) comboPagamento.getSelectedItem();

            if (nome.isEmpty() || valorTxt.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Preencha nome e valor.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (catSel == null || "Definir categoria".equals(catSel.getNome())) {
                JOptionPane.showMessageDialog(frame, "Escolha uma categoria válida.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (forma == null || "Definir tipo de pagamento".equals(forma)) {
                JOptionPane.showMessageDialog(frame, "Escolha uma forma de pagamento válida.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            BigDecimal valor;
            try {
                valor = new BigDecimal(valorTxt.replace(",", ".")).setScale(2, RoundingMode.HALF_UP);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Valor inválido. Ex.: 150.50", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int newId = pagamentos.size() + 1;
            Pagamento p = new Pagamento(newId, nome, valor, forma, LocalDate.now());

            // Detalhes do pagamento:
            Map<String, String> detalhes = new HashMap<>();
            // Captura dos campos de Cartão (se existir)
            for (Map.Entry<String, JTextField> entry : camposExtras.entrySet()) {
                String key = entry.getKey();
                String val = entry.getValue().getText().trim();
                if (!val.isEmpty()) detalhes.put(key, val);
            }
            // Adiciona detalhes fixos de PIX/Transferência
            if ("PIX".equals(forma)) {
                detalhes.put("Chave PIX", "org.fundacao@gmail.com");
            } else if ("Transferência Bancária".equals(forma)) {
                detalhes.put("Banco", "001 - Banco do Brasil");
                detalhes.put("Agência", "0001");
                detalhes.put("Conta", "67890-1");
            }
            p.setDetalhes(detalhes);

            pagamentos.add(p);
            categoriasAssociadas.add(catSel);

            JOptionPane.showMessageDialog(frame,
                "Doação registrada!\n" +
                "Nome: " + p.getNomeDoador() + "\n" +
                "Valor: R$ " + p.getValor() + "\n" +
                "Categoria: " + catSel.getNome() + "\n" +
                "Pagamento: " + p.getFormaPagamento() + "\n" +
                "Data: " + p.getData() + "\n" +
                "Detalhes: " + p.getDetalhes(),
                "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            // Limpa campos
            campoNome.setText("");
            campoValor.setText("");
            comboCategoria.setSelectedIndex(0);
            comboPagamento.setSelectedIndex(0);
            camposExtras.values().forEach(tf -> tf.setText(""));
            // força o painel de detalhes a voltar ao estado inicial
            comboPagamento.dispatchEvent(new java.awt.event.ActionEvent(comboPagamento, 0, ""));
        });

        // Ação Ver Registros
        btnVer.addActionListener(e -> {
            if (pagamentos.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Nenhum registro ainda.", "Registros", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < pagamentos.size(); i++) {
                Pagamento p = pagamentos.get(i);
                Categoria c = categoriasAssociadas.get(i);
                sb.append("#").append(p.getId()).append(" - ")
                .append(p.getNomeDoador()).append(" | R$ ")
                .append(p.getValor()).append(" | Categoria: ")
                .append(c.getNome()).append(" | Forma: ")
                .append(p.getFormaPagamento()).append(" | Data: ")
                .append(p.getData()).append(" | Detalhes: ")
                .append(p.getDetalhes()).append("\n");
            }
            JTextArea area = new JTextArea(sb.toString());
            area.setEditable(false);
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(480, 300));
            JOptionPane.showMessageDialog(frame, scroll, "Registros de Doações", JOptionPane.INFORMATION_MESSAGE);
        });

        frame.add(painel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
